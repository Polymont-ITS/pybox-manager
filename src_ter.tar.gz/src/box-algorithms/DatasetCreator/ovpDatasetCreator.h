#ifndef __OpenViBEPlugins_BoxAlgorithm_DatasetCreator_H__
#define __OpenViBEPlugins_BoxAlgorithm_DatasetCreator_H__

#if defined TARGET_HAS_ThirdPartyPython

#include <Python.h>

#if defined(PY_MAJOR_VERSION) && (PY_MAJOR_VERSION == 2)

#include "../../ovp_defines.h"
#include <openvibe/ov_all.h>
#include <toolkit/ovtk_all.h>

#include <string.h>
#include <string>
#include <vector>
//#include <map>

namespace OpenViBEPlugins
{
	namespace Python
	{
		

		class CBoxAlgorithmDatasetCreator : virtual public OpenViBEToolkit::TBoxAlgorithm < IBoxAlgorithm >
		{
		public:
			virtual void release() { delete this; }

			virtual OpenViBE::uint64 getClockFrequency();
			virtual OpenViBE::boolean initialize();
			virtual OpenViBE::boolean uninitialize();
			virtual OpenViBE::boolean processClock(OpenViBE::CMessageClock& rMessageClock);
			virtual OpenViBE::boolean processInput(OpenViBE::uint32 ui32InputIndex);
			virtual OpenViBE::boolean process();

			_IsDerivedFromClass_Final_(OpenViBEToolkit::TBoxAlgorithm < IBoxAlgorithm >, OVP_ClassId_BoxAlgorithm_DatasetCreator);

		protected:

			OpenViBE::uint64 m_ui64ClockFrequency;
			CString m_sScriptFilename;
			
			std::vector < OpenViBEToolkit::TDecoder < CBoxAlgorithmDatasetCreator >* > m_vDecoders;
			std::vector < OpenViBEToolkit::TEncoder < CBoxAlgorithmDatasetCreator >* > m_vEncoders;

			//std::map<char,PyObject *> m_PyObjectMap;
			
			PyObject *m_pBox, *m_pBoxInput, *m_pBoxOutput, *m_pBoxSetting, *m_pBoxCurrentTime;
			PyObject *m_pBoxInitialize, *m_pBoxProcess, *m_pBoxUninitialize;
            OpenViBE::boolean m_bInitializeSucceeded ;
            
			
			OpenViBE::boolean logSysStdout();
			OpenViBE::boolean logSysStderr();
			void buildPythonSettings();

			OpenViBE::boolean initializePythonSafely();
			OpenViBE::boolean clearPyObjectMap();
			OpenViBE::boolean transferStreamedMatrixInputChunksToPython(const OpenViBE::uint32 input_index);
			OpenViBE::boolean transferStreamedMatrixOutputChunksFromPython(const OpenViBE::uint32 output_index);
			OpenViBE::boolean transferSignalInputChunksToPython(const OpenViBE::uint32 input_index);
			OpenViBE::boolean transferSignalOutputChunksFromPython(const OpenViBE::uint32 output_index);
			OpenViBE::boolean transferStimulationInputChunksToPython(const OpenViBE::uint32 input_index);
			OpenViBE::boolean transferStimulationOutputChunksFromPython(const OpenViBE::uint32 output_index);


			
		};
		
		class CBoxAlgorithmDatasetCreatorListener : public OpenViBEToolkit::TBoxListener < IBoxListener >
		{
		public:
			virtual OpenViBE::boolean onInputAdded(Kernel::IBox& rBox, const OpenViBE::uint32 ui32Index) 
			{
				rBox.setInputType(ui32Index, OV_TypeId_StreamedMatrix);
				return true;
			};

			virtual OpenViBE::boolean onOutputAdded(Kernel::IBox& rBox, const OpenViBE::uint32 ui32Index) 
			{ 
				rBox.setOutputType(ui32Index, OV_TypeId_StreamedMatrix);
				return true; 
			};

			_IsDerivedFromClass_Final_(OpenViBEToolkit::TBoxListener < IBoxListener >, OV_UndefinedIdentifier);
		};
		
		class CBoxAlgorithmDatasetCreatorDesc : virtual public IBoxAlgorithmDesc
		{
		public:

			virtual void release() { }

			virtual CString getName() const override { return CString("DatasetCreator"); }
			virtual CString getAuthorName() const override { return CString("Yannis Bendi-Ouis and Jimmy LeBlanc"); }
			virtual CString getAuthorCompanyName() const override { return CString("CICIT Garches, Inria"); }
			virtual CString getShortDescription() const override { return CString("Monitor the user to create a dataset."); }
			virtual CString getDetailedDescription() const override { return CString(""); }
			virtual CString getCategory() const override { return CString("Acquisition and network IO"); }
			virtual CString getVersion() const override { return CString("0.1"); }
			virtual CString getStockItemName() const override { return CString("gtk-missing-image"); }

			virtual OpenViBE::CIdentifier getCreatedClass() const override { return OVP_ClassId_BoxAlgorithm_DatasetCreator; }
			virtual IPluginObject* create()       { return new OpenViBEPlugins::Python::CBoxAlgorithmDatasetCreator; }
			virtual IBoxListener* createBoxListener() const override { return new CBoxAlgorithmDatasetCreatorListener; }
			virtual void releaseBoxListener(IBoxListener* pBoxListener)() const override { delete pBoxListener; }

			virtual OpenViBE::boolean getBoxPrototype(Kernel::IBoxProto& prototype) const
			{
				//prototype.addInput  ("Input",  OV_TypeId_StreamedMatrix);
				//prototype.addInput  ("Input stimulations", OV_TypeId_Stimulations);
                prototype.addInput  ("input", OV_TypeId_StreamedMatrix);
				//prototype.addOutput ("Output", OV_TypeId_StreamedMatrix);
				//prototype.addOutput ("Output stimulations", OV_TypeId_Stimulations);
                prototype.addOutput ("stim_out", OV_TypeId_Stimulations);
				prototype.addSetting("Clock frequency (Hz)", OV_TypeId_Integer, "64");
				////prototype.addSetting("Script", OV_TypeId_Script, "");
                prototype.addSetting("Path directory", OV_TypeId_Filename, "");
                prototype.addSetting("Label_1", OV_TypeId_String, "");
                prototype.addSetting("Label_2", OV_TypeId_String, "");
                prototype.addSetting("Label_3", OV_TypeId_String, "");
                prototype.addSetting("Label_4", OV_TypeId_String, "");
                prototype.addSetting("Label_5", OV_TypeId_String, "");
                prototype.addSetting("Label_6", OV_TypeId_String, "");
                prototype.addSetting("Several CSV", OV_TypeId_Boolean, "false");
                prototype.addSetting("Number of folds", OV_TypeId_Integer, "1");
                prototype.addSetting("Number of actions", OV_TypeId_Integer, "12");
				//prototype.addFlag(Kernel::BoxFlag_IsUnstable);
				
				prototype.addFlag(Kernel::BoxFlag_CanAddInput);
				prototype.addFlag(Kernel::BoxFlag_CanModifyInput);
				prototype.addFlag(Kernel::BoxFlag_CanAddOutput);
				prototype.addFlag(Kernel::BoxFlag_CanModifyOutput);
				prototype.addFlag(Kernel::BoxFlag_CanAddSetting);
				prototype.addFlag(Kernel::BoxFlag_CanModifySetting);

				prototype.addInputSupport(OV_TypeId_Signal);
				prototype.addInputSupport(OV_TypeId_Stimulations);
				prototype.addInputSupport(OV_TypeId_StreamedMatrix);

				prototype.addOutputSupport(OV_TypeId_Signal);
				prototype.addOutputSupport(OV_TypeId_Stimulations);
				prototype.addOutputSupport(OV_TypeId_StreamedMatrix);
				
				return true;
			}

			_IsDerivedFromClass_Final_(IBoxAlgorithmDesc, OVP_ClassId_BoxAlgorithm_DatasetCreatorDesc);
		};
	};
};

#endif // #if defined(PY_MAJOR_VERSION) && (PY_MAJOR_VERSION == 2)

#endif // TARGET_HAS_ThirdPartyPython

#endif // __OpenViBEPlugins_BoxAlgorithm_DatasetCreator_H__

