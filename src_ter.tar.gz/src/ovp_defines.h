# pragma once

// Boxes

//---------------------------------------------------------------------------------------------------
#define OVP_ClassId_BoxAlgorithm_Python3                OpenViBE::CIdentifier(0x5DC4F669, 0xD3FD4D63)
#define OVP_ClassId_BoxAlgorithm_Python3Desc                OpenViBE::CIdentifier(0x404B6FFD, 0x12BDD423)
#define OVP_ClassId_BoxAlgorithm_TrashboxDesc                OpenViBE::CIdentifier( 0x3c35adbd,  0x2ae86cd4)
#define OVP_ClassId_BoxAlgorithm_Trashbox                OpenViBE::CIdentifier( 0x8114ab4e,  0x766b346b)
#define OVP_ClassId_BoxAlgorithm_TDesc                OpenViBE::CIdentifier( 0x42455194,  0x2fa314cf)
#define OVP_ClassId_BoxAlgorithm_T                OpenViBE::CIdentifier( 0x852e719b,  0xa5a43ecb)
#define OVP_ClassId_BoxAlgorithm_Random_ForestDesc                OpenViBE::CIdentifier( 0x35897a37,  0x367dfe65)
#define OVP_ClassId_BoxAlgorithm_Random_Forest                OpenViBE::CIdentifier( 0x658f8ee6,  0xefa5409f)
#define OVP_ClassId_BoxAlgorithm_Extra_TreesDesc                OpenViBE::CIdentifier( 0x65cb6d12,  0xed4b6075)
#define OVP_ClassId_BoxAlgorithm_Extra_Trees                OpenViBE::CIdentifier( 0x88c0b2d2,  0x61ce21ae)
#define OVP_ClassId_BoxAlgorithm_KNearestNeighborsDesc                OpenViBE::CIdentifier( 0xee556f3a,  0x77a48a3c)
#define OVP_ClassId_BoxAlgorithm_KNearestNeighbors                OpenViBE::CIdentifier( 0x8bf17d83,  0xb4ed335d)
#define OVP_ClassId_BoxAlgorithm_SVMDesc                OpenViBE::CIdentifier( 0xe98c66ad,  0xb7cc9745)
#define OVP_ClassId_BoxAlgorithm_SVM                OpenViBE::CIdentifier( 0xf8891c4b,  0xa4f1e585)
#define OVP_ClassId_BoxAlgorithm_LDADesc                OpenViBE::CIdentifier( 0x8dda021f,  0xe08204b4)
#define OVP_ClassId_BoxAlgorithm_LDA                OpenViBE::CIdentifier( 0x7ffa155d,  0x69abd2c0)
#define OVP_ClassId_BoxAlgorithm_DataVizDesc                OpenViBE::CIdentifier( 0xf71943e6,  0xfe3397d3)
#define OVP_ClassId_BoxAlgorithm_DataViz                OpenViBE::CIdentifier( 0x98413250,  0xa2b79c32)
#define OVP_ClassId_BoxAlgorithm_Logistic_RegressionDesc                OpenViBE::CIdentifier( 0xaabf6e49,  0x4cba8ae9)
#define OVP_ClassId_BoxAlgorithm_Logistic_Regression                OpenViBE::CIdentifier( 0xe1a155c6,  0x26b78f9d)
#define OVP_ClassId_BoxAlgorithm_lalalaDesc                OpenViBE::CIdentifier( 0xed96f98def5b92e3,  0x409f51e3b4f65f24)
#define OVP_ClassId_BoxAlgorithm_lalala                OpenViBE::CIdentifier( 0xa26accb219a0f53d,  0xfee4f7cb59009aea)