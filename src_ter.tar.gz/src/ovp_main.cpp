#if defined(WIN32) && defined(TARGET_BUILDTYPE_Debug)
// Windows debug build doesn't typically link as most people don't have the python debug library.
#else

#if defined TARGET_HAS_ThirdPartyPython3

#include "box-algorithms/ovpCBoxAlgorithmPython3.h"
#include "box-algorithms/Trashbox/ovpTrashbox.h"
#include "box-algorithms/T/ovpT.h"
#include "box-algorithms/Random_Forest/ovpRandom_Forest.h"
#include "box-algorithms/Extra_Trees/ovpExtra_Trees.h"
#include "box-algorithms/KNearestNeighbors/ovpKNearestNeighbors.h"
#include "box-algorithms/SVM/ovpSVM.h"
#include "box-algorithms/LDA/ovpLDA.h"
#include "box-algorithms/DataViz/ovpDataViz.h"
#include "box-algorithms/Logistic_Regression/ovpLogistic_Regression.h"

#if defined(PY_MAJOR_VERSION) && (PY_MAJOR_VERSION == 3)

#ifdef TARGET_OS_Windows
#include "windows.h"
#endif

#include <string>
#include <iostream>

using namespace OpenViBE;
using namespace /*OpenViBE::*/Plugins;
using namespace std;

class CPythonInitializer
{
public:
	CPythonInitializer();
	~CPythonInitializer();
	bool isPythonAvailable() const { return m_pythonAvailable; }
private:
#ifdef TARGET_OS_Windows
	static bool checkPythonPath();
#endif
	// PyThreadState *m_pMainPyThreadState;
	bool m_pythonAvailable;
};

#ifdef TARGET_OS_Windows
bool CPythonInitializer::checkPythonPath()
{
#ifdef HAVE_WORKING_PYCHECK
	const CString testCmd = "\"" + Directories::getBinDir() + "\\openvibe-py3-check.exe\"";
	if (system(testCmd.toASCIIString()))
	{
		cout << "Warning: The Python version found does not seem to be compatible and using it would cause Designer to crash."
				<< "Check that Python 3.7 is installed and/or your PYTHONPATH/PYTHONHOME is set correctly." << endl
				<< "Disabling the Python 3 scripting box for now." << endl;
		return false;
	}
#endif
	wstring ws(Py_GetPath());
	string path(ws.begin(), ws.end());

	size_t found = path.find_first_of(';');
	while (found != string::npos)
	{
		if (found > 0)
		{
			string filename   = path.substr(0, found);
			const bool exists = (_access(filename.c_str(), 0) == 0);
			if (exists) { return true; }
			// cout << "Found Python in : " << path.substr(0,found) << endl;
			// else { cout << "NOT found : " << path.substr(0,found) << endl; }
		}
		path  = path.substr(found + 1);
		found = path.find_first_of(';');
	}

	cout << "Python directory not found. You probably have a corrupted python installation!" << endl;
	cout << "The tried path from Py_GetPath() was [" << Py_GetPath() << "]\n";

	return false;
}
#endif

CPythonInitializer::CPythonInitializer() : m_pythonAvailable(false)
{
	//m_pMainPyThreadState = nullptr;

#ifdef TARGET_OS_Windows
	__try
	{
		if (!Py_IsInitialized())
		{
			// We do not care about the last file, since it is the OpenViBE runtime path
			if (checkPythonPath())
			{
				Py_Initialize();
				m_pythonAvailable = true;
			}
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) { }
#else
		if (!Py_IsInitialized())
		{
			Py_Initialize();
			m_pythonAvailable = true;
		}
#endif
}

CPythonInitializer::~CPythonInitializer()
{
	if (m_pythonAvailable)
	{
		m_pythonAvailable = false;
		Py_Finalize();
	}
}

OVP_Declare_Begin()
	static CPythonInitializer pythonInit;
	if (pythonInit.isPythonAvailable()) {
		OVP_Declare_New(Python::CBoxAlgorithmPython3Desc);
		OVP_Declare_New(Python::CBoxAlgorithmTrashboxDesc);
		OVP_Declare_New(Python::CBoxAlgorithmTDesc);
		OVP_Declare_New(Python::CBoxAlgorithmRandom_ForestDesc);
		OVP_Declare_New(Python::CBoxAlgorithmExtra_TreesDesc);
		OVP_Declare_New(Python::CBoxAlgorithmKNearestNeighborsDesc);
		OVP_Declare_New(Python::CBoxAlgorithmSVMDesc);
		OVP_Declare_New(Python::CBoxAlgorithmLDADesc);
		OVP_Declare_New(Python::CBoxAlgorithmDataVizDesc);
		OVP_Declare_New(Python::CBoxAlgorithmLogistic_RegressionDesc);		
		}
OVP_Declare_End()

#else
#pragma message ("WARNING: Python 3.x headers are required to build the Python plugin, different includes found, skipped")
#endif // #if defined(PY_MAJOR_VERSION) && (PY_MAJOR_VERSION == 2)

#endif // TARGET_HAS_ThirdPartyPython3

#endif
