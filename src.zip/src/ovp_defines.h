#ifndef __OpenViBEPlugins_Defines_H__
#define __OpenViBEPlugins_Defines_H__

//___________________________________________________________________//
//                                                                   //
// Plugin identifiers                                                //
//___________________________________________________________________//
//                                                                   //
#define OVP_ClassId_BoxAlgorithm_Python                     OpenViBE::CIdentifier(0x5DC4F669, 0xD3FD4D64)
#define OVP_ClassId_BoxAlgorithm_PythonDesc                 OpenViBE::CIdentifier(0x404B6FFD, 0x12BDD429)
#define OVP_ClassId_BoxAlgorithm_TrainerMLDesc                 OpenViBE::CIdentifier(0x75001C75, 0x58993190)
#define OVP_ClassId_BoxAlgorithm_TrainerML                 OpenViBE::CIdentifier(0x3C446E8D, 0x316B6594)
#define OVP_ClassId_BoxAlgorithm_SVMDesc                 OpenViBE::CIdentifier(0x4CB50D1F, 0x4C713CFF)
#define OVP_ClassId_BoxAlgorithm_SVM                 OpenViBE::CIdentifier(0x3C404490, 0x6BA20795)
#define OVP_ClassId_BoxAlgorithm_SGDDesc                 OpenViBE::CIdentifier(0x246B7DC8, 0x4048486E)
#define OVP_ClassId_BoxAlgorithm_SGD                 OpenViBE::CIdentifier(0x3C3D1A94, 0x25DA2995)
#define OVP_ClassId_BoxAlgorithm_RMDMDesc                 OpenViBE::CIdentifier(0x53D65F1A, 0x27F75F4D)
#define OVP_ClassId_BoxAlgorithm_RMDM                 OpenViBE::CIdentifier(0x3C36469B, 0x1A4A6D97)
#define OVP_ClassId_BoxAlgorithm_Riemann_Tangent_SpaceDesc                 OpenViBE::CIdentifier(0x2B8B4FC4, 0x1BCF6ABC)
#define OVP_ClassId_BoxAlgorithm_Riemann_Tangent_Space                 OpenViBE::CIdentifier(0x3C331C9F, 0x54820F97)
#define OVP_ClassId_BoxAlgorithm_Random_ForestDesc                 OpenViBE::CIdentifier(0x0340406D, 0x0FA7762B)
#define OVP_ClassId_BoxAlgorithm_Random_Forest                 OpenViBE::CIdentifier(0x3C3072A2, 0x0EBA3198)
#define OVP_ClassId_BoxAlgorithm_ProcessMLDesc                 OpenViBE::CIdentifier(0x5AF63116, 0x037E019B)
#define OVP_ClassId_BoxAlgorithm_ProcessML                 OpenViBE::CIdentifier(0x3C2D48A6, 0x48F15399)
#define OVP_ClassId_BoxAlgorithm_NearestCentroidDesc                 OpenViBE::CIdentifier(0x32AB21BF, 0x77560D0A)
#define OVP_ClassId_BoxAlgorithm_NearestCentroid                 OpenViBE::CIdentifier(0x3C291EAA, 0x03297599)
#define OVP_ClassId_BoxAlgorithm_MLPDesc                 OpenViBE::CIdentifier(0x62160312, 0x5F0523E9)
#define OVP_ClassId_BoxAlgorithm_MLP                 OpenViBE::CIdentifier(0x3C234AB1, 0x7799399B)
#define OVP_ClassId_BoxAlgorithm_Logistic_RegressionDesc                 OpenViBE::CIdentifier(0x39CB73BB, 0x52DC2F58)
#define OVP_ClassId_BoxAlgorithm_Logistic_Regression                 OpenViBE::CIdentifier(0x3C2020B4, 0x31D15B9B)
#define OVP_ClassId_BoxAlgorithm_LDADesc                 OpenViBE::CIdentifier(0x11816465, 0x46B43AC7)
#define OVP_ClassId_BoxAlgorithm_LDA                 OpenViBE::CIdentifier(0x3C1C76B8, 0x6C097D9C)
#define OVP_ClassId_BoxAlgorithm_KNearestNeighborsDesc                 OpenViBE::CIdentifier(0x40EC45B7, 0x2E6351A6)
#define OVP_ClassId_BoxAlgorithm_KNearestNeighbors                 OpenViBE::CIdentifier(0x3C1622BF, 0x6078419E)
#define OVP_ClassId_BoxAlgorithm_GaussianNBDesc                 OpenViBE::CIdentifier(0x18A13660, 0x223B5D15)
#define OVP_ClassId_BoxAlgorithm_GaussianNB                 OpenViBE::CIdentifier(0x3C1378C3, 0x1AB0639E)
#define OVP_ClassId_BoxAlgorithm_Extra_TreesDesc                 OpenViBE::CIdentifier(0x7057270A, 0x16126884)
#define OVP_ClassId_BoxAlgorithm_Extra_Trees                 OpenViBE::CIdentifier(0x3C0F4EC6, 0x54E8059F)
#define OVP_ClassId_BoxAlgorithm_Decision_Tree_ClassifierDesc                 OpenViBE::CIdentifier(0x480C17B3, 0x09EA73F4)
#define OVP_ClassId_BoxAlgorithm_Decision_Tree_Classifier                 OpenViBE::CIdentifier(0x3C0C24CA, 0x0F2027A0)
#define OVP_ClassId_BoxAlgorithm_DataVizDesc                 OpenViBE::CIdentifier(0x1FC1085C, 0x7DC17F63)
#define OVP_ClassId_BoxAlgorithm_DataViz                 OpenViBE::CIdentifier(0x3C097ACE, 0x495849A0)
#define OVP_ClassId_BoxAlgorithm_DatasetCreatorDesc                 OpenViBE::CIdentifier(0x4F2C69AF, 0x65701641)
#define OVP_ClassId_BoxAlgorithm_DatasetCreator                 OpenViBE::CIdentifier(0x3C0226D5, 0x3DC70DA2)
#define OVP_ClassId_BoxAlgorithm_BaggingDesc                 OpenViBE::CIdentifier(0x26E25A58, 0x594821B1)
#define OVP_ClassId_BoxAlgorithm_Bagging                 OpenViBE::CIdentifier(0x3BFF7CD8, 0x77FF2FA2)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x7E974B01, 0x4D1F2D20)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x3BFC52DC, 0x323751A3)
#define OVP_ClassId_BoxAlgorithm_Extra_TreesDesc                 OpenViBE::CIdentifier(0x2DA021CF, 0x768A5AB4)
#define OVP_ClassId_BoxAlgorithm_Extra_Trees                 OpenViBE::CIdentifier(0x31912D2E, 0x5E9A14BA)
#define OVP_ClassId_BoxAlgorithm_GaussianNBDesc                 OpenViBE::CIdentifier(0x34AC7D5D, 0x767B34FC)
#define OVP_ClassId_BoxAlgorithm_GaussianNB                 OpenViBE::CIdentifier(0x259D0055, 0x74F2093D)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x0C616E07, 0x6A52406C)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x259A5659, 0x2F2A2B3D)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x33046BEB, 0x2BE21825)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x23CA0C57, 0x7A21079F)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x04D36B7B, 0x682A249A)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x0E8051C5, 0x081B3618)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x47B26D9A, 0x285D1C12)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x0D396B2C, 0x45EA7E5D)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x483C7503, 0x074C6F04)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x0BD934B0, 0x557756A7)
#define OVP_ClassId_BoxAlgorithm_ADADesc                 OpenViBE::CIdentifier(0x1A642EB5, 0x0EA02CF7)
#define OVP_ClassId_BoxAlgorithm_ADA                 OpenViBE::CIdentifier(0x01C84DC4, 0x438822C4)
#define OVP_ClassId_BoxAlgorithm_ProcessMLDesc                 OpenViBE::CIdentifier(0x0E009798, 0xF6DA48C9)
#define OVP_ClassId_BoxAlgorithm_ProcessML                 OpenViBE::CIdentifier(0xCC588554, 0x5BBCC158)
#define OVP_ClassId_BoxAlgorithm_TrainerMLDesc                 OpenViBE::CIdentifier(0x150C3165, 0xCC426C9E)
#define OVP_ClassId_BoxAlgorithm_TrainerML                 OpenViBE::CIdentifier(0xDCE01491, 0x438D6BE7)
#define OVP_ClassId_BoxAlgorithm_SVMDesc                 OpenViBE::CIdentifier(0x97FB759A, 0xDD5F7716)
#define OVP_ClassId_BoxAlgorithm_SVM                 OpenViBE::CIdentifier(0x8778E0E2, 0x371432D4)
#define OVP_ClassId_BoxAlgorithm_SGDDesc                 OpenViBE::CIdentifier(0xC21F6D2E, 0xD7DF5335)
#define OVP_ClassId_BoxAlgorithm_SGD                 OpenViBE::CIdentifier(0xAD0E75ED, 0xB30A8C83)
#define OVP_ClassId_BoxAlgorithm_Riemann_Tangent_SpaceDesc                 OpenViBE::CIdentifier(0xA5A12DFF, 0x2A4077DF)
#define OVP_ClassId_BoxAlgorithm_Riemann_Tangent_Space                 OpenViBE::CIdentifier(0x431E5D5F, 0x58E46272)
#define OVP_ClassId_BoxAlgorithm_Random_ForestDesc                 OpenViBE::CIdentifier(0xCCDB3FD5, 0x60C8FD4D)
#define OVP_ClassId_BoxAlgorithm_Random_Forest                 OpenViBE::CIdentifier(0x27861D53, 0xA85FBA11)
#define OVP_ClassId_BoxAlgorithm_RMDMDesc                 OpenViBE::CIdentifier(0x75601281, 0x6A26C5F6)
#define OVP_ClassId_BoxAlgorithm_RMDM                 OpenViBE::CIdentifier(0x44FC8911, 0xA7C9CFE7)
#define OVP_ClassId_BoxAlgorithm_NearestCentroidDesc                 OpenViBE::CIdentifier(0x5331A7E0, 0x8450784E)
#define OVP_ClassId_BoxAlgorithm_NearestCentroid                 OpenViBE::CIdentifier(0x1B5C3630, 0x7E8E65E4)
#define OVP_ClassId_BoxAlgorithm_MLPDesc                 OpenViBE::CIdentifier(0x523F9F5F, 0x2B726572)
#define OVP_ClassId_BoxAlgorithm_MLP                 OpenViBE::CIdentifier(0x15E2321D, 0xBDE1F1B6)
#define OVP_ClassId_BoxAlgorithm_Logistic_RegressionDesc                 OpenViBE::CIdentifier(0xE3FA3C99, 0x3B266371)
#define OVP_ClassId_BoxAlgorithm_Logistic_Regression                 OpenViBE::CIdentifier(0x2F1902B2, 0x267265E4)
#define OVP_ClassId_BoxAlgorithm_LDADesc                 OpenViBE::CIdentifier(0x3ADDAEBF, 0x6C4402E8)
#define OVP_ClassId_BoxAlgorithm_LDA                 OpenViBE::CIdentifier(0x443BDD8D, 0x9DF9023E)
#define OVP_ClassId_BoxAlgorithm_KNearestNeighborsDesc                 OpenViBE::CIdentifier(0x407962B9, 0x03613BC1)
#define OVP_ClassId_BoxAlgorithm_KNearestNeighbors                 OpenViBE::CIdentifier(0x6D2080B9, 0xAEE71670)
#define OVP_ClassId_BoxAlgorithm_BaggingDesc                 OpenViBE::CIdentifier(0x1957B849, 0x76AECA73)
#define OVP_ClassId_BoxAlgorithm_Bagging                 OpenViBE::CIdentifier(0x96FA6193, 0x44EA89A6)
#define OVP_ClassId_BoxAlgorithm_Decision_Tree_ClassifierDesc                 OpenViBE::CIdentifier(0xC53FB2A7, 0x88BA667F)
#define OVP_ClassId_BoxAlgorithm_Decision_Tree_Classifier                 OpenViBE::CIdentifier(0xA167A1A3, 0x634F179E)
#define OVP_ClassId_BoxAlgorithm_DatasetCreatorDesc                 OpenViBE::CIdentifier(0x0BF8EAE3, 0x3D2CEFA3)
#define OVP_ClassId_BoxAlgorithm_DatasetCreator                 OpenViBE::CIdentifier(0x25329CE8, 0xFCE57272)
#define OVP_ClassId_BoxAlgorithm_DataVizDesc                 OpenViBE::CIdentifier(0x058D1D52, 0x70D4A0F5)
#define OVP_ClassId_BoxAlgorithm_DataViz                 OpenViBE::CIdentifier(0x5AFC7D7E, 0x13990170)
//___________________________________________________________________//
//                                                                   //
// Gloabal defines                                                   //
//___________________________________________________________________//
//                                                                   //

#if 0
#ifdef TARGET_HAS_ThirdPartyOpenViBEPluginsGlobalDefines
 #include "ovp_global_defines.h"
#endif // TARGET_HAS_ThirdPartyOpenViBEPluginsGlobalDefines
#endif

#endif // __OpenViBEPlugins_Defines_H__
